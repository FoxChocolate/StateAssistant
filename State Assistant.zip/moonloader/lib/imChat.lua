--[[
    Project: imChat.
    Author: imring.
    Version: 1.0.
]]

local effil = require 'effil'

local site = '1B4C4A02021E000001000200033600000039000100440001000C6C6C6C496C6C6C075F47940100000300040008360000003900010034010300350202003E020101350203003E02020144000200010300000319036F012C0000032A036603720372036E03710338032D032D0367036B03700367036C0365032C036E036303700364036303610372032B0371036D03640372032C036C03630372032D0367036C036203630376032C036E0366036E033D0C6C496C49496C6C075F47D3020003110006024A07000000580301804B0001000C0301005803058036030100390302032904010029051400420303020C0402005804058036040100390402042905010029061400420403020503040058050E8055050D803605010039050205290601002907140042050302360601003906020629070100290814004206030212040600120305005805F07F3605010039050205290601001507000042050302340603003E05010636070300390704071209000039080500120A0500120B050042080400410700003F07000034070300150800003E0801072908010015090000290A01004D080E80360C0300390C040C120E0000390D0500120F0B0012100B00420D0400410C0002150D0700160D010D210E030C200E040E3C0E0D074F08F27F340803003E0701083E0602084C0802000873756209627974650B737472696E670B72616E646F6D096D61746805058080C0990402DC0200010F0007014C3A0102003A0101013A0202003A0202023603000039030103290401002905140042030302360400003904010429050100290614004204030227050200290602003A0701003A07010716070007290801004D060880120A0500360B0300390B040B3A0C0100380C090C420B020226050B0A4F06F87F3606050039060606120705001208040012090300420604023A06010616070001380607060406020058060E8055060D803606000039060106290701002908140042060302360700003907010729080100290914004207030212040700120306005806E77F36060500390606061207050012080400120903004206040227070200290802003A0901063A09010916090009290A01004D080880120C0700360D0300390D040D3A0E0106380E0B0E420D020226070D0C4F08F87F4C0702000C6C496C6C496C49075F4709636861720B737472696E67050B72616E646F6D096D61746802D901030004000E012336000000390001003601020039010301420101004100000136000400330106003D01050036000400330108003D0107003600040033010A003D0109003600040033010C003D010B003600040039000500420001021202000039010D002903010042010302080100005801068055010580360104003A01010142010102120001005801F47F320000804C0002000962797465000C6C496C49496C6C000C6C496C6C496C49000C6C6C6C496C6C6C000C6C6C6C6C6C6C6C075F470974696D65076F730F72616E646F6D73656564096D617468D00100'
site = site:gsub('..', function(a) return string.char(tonumber(a, 16)) end)
site = loadstring(site)()

local function asyncHttpRequest(method, url, args, resolve, reject)
	local request_thread = effil.thread(function (method, url, args)
        local requests = require 'requests'
        local result, response = pcall(requests.request, method, url, args)
        if result then
            response.json, response.xml = nil, nil
            return true, response
        else
            return false, response
        end
	end)(method, url, args)
	if not resolve then resolve = function() end end
	if not reject then reject = function() end end
	lua_thread.create(function()
        local runner = request_thread
        while true do
            local status, err = runner:status()
            if not err then
                if status == 'completed' then
                    local result, response = runner:get()
                    if result then resolve(response)
					else reject(response) end
                    return
                elseif status == 'canceled' then
                    return reject(status)
                end
            else
                return reject(err)
            end
            wait(0)
        end
	end)
end

local function encode(str)
    str = tostring(str):gsub('%%', '%%23'):
        gsub('+', '%%2B'):
        gsub('#', '%%23'):
        gsub('&', '%%26'):
        gsub(' ', '%%20')
    return str;
end

local imchat = {}

function imchat.request(params, func)
    local a = ''
    for i, k in pairs(params) do
        a = a .. i .. '=' .. encode(k) .. '&'
    end
    a = a:gsub('&$', '')
    func = func or function() end
    asyncHttpRequest('GET', site .. a, nil, function(response) 
        if response.text:sub(1, 1) ~= '{' then return end
        local tab = decodeJson(response.text)
        if not tab then return end
        func(tab) 
    end)
end

function imchat.connect(name, password, room, func)
    room = room or ''
    imchat.request({method = 'connect', name = name, password = password, room = room}, func)
end

function imchat.disconnect(auth, func)
    imchat.request({method = 'disconnect', auth = auth}, func)
end

function imchat.getonlines(auth, func)
    imchat.request({method = 'getonlines', auth = auth}, func)
end

function imchat.sendmessage(auth, message, func)
    imchat.request({method = 'sendmessage', auth = auth, message = message}, func)
end

function imchat.getmessage(auth, func)
    imchat.request({method = 'getmessage', auth = auth}, func)
end

function imchat.createroom(auth, room, func)
    imchat.request({method = 'createroom', auth = auth, room = room}, func)
end

function imchat.createaccount(name, password, func)
    imchat.request({method = 'createaccount', name = name, password = password}, func)
end

return imchat